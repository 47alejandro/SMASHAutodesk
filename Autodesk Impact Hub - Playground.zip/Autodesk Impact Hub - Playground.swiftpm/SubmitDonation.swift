import SwiftUI

struct SubmitDonation: View {
    var body: some View {
        Text("Submit donation")
            .navigationTitle("Submit Donation")
    }
}

struct SubmitDonation_Previews: PreviewProvider {
    static var previews: some View {
        SubmitDonation()
    }
}
